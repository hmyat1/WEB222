/**
 * WEB222 – Assignment 04
 *
 * I declare that this assignment is my own work in accordance with
 * Seneca Academic Policy. No part of this assignment has been
 * copied manually or electronically from any other source
 * (including web sites) or distributed to other students.
 *
 * Please update the following with your information:
 *
 *      Name:       <Hla Myint Myat>
 *      Student ID: <185923216>
 *      Date:       <20.11.23>
 */

// All of our data is available on the global `window` object.
// Create local variables to work with it in this file.
const { products, categories } = window;

// For debugging, display all of our data in the console
console.log({ products, categories }, "Store Data");

// Here, we create arrays of descriptions for men, women, and children hoodies respectively
let MenArr = [];
let WomenArr = [];
let ChildrenArr = [];

for (let i = 0; i < products.length; i++) {
  products[i].categories.forEach(function (element) {
    if (element === "HOO-MEN" && products[i].discontinued === false) {
      MenArr.push(products[i].description);
    } else if (element === "HOO-WOMEN" && products[i].discontinued === false) {
      WomenArr.push(products[i].description);
    } else if (element === "HOO-CHILDREN" && products[i].discontinued === false) {
      ChildrenArr.push(products[i].description);
    }
  });
}

// Creating the navbar dynamically
let menu = document.getElementById("menu");
for (let i = 0; i < categories.length; i++) {
  let newMenuItem = document.createElement("button");
  newMenuItem.textContent = categories[i].name;
  newMenuItem.id = categories[i].name;
  menu.appendChild(newMenuItem);
}

// Prints the description of the product
function descriptionPrinter(category) {
  // Whenever the user clicks on an element, the program prints the description of the product to the console
  let tableRows = document.getElementsByClassName("tbl-row");

  // Using the length as per the category and printing description by using the parallel array concept
  if (category === "HOO-MEN") {
    for (let i = 0; i < MenArr.length; i++) {
      tableRows[i].addEventListener("click", function () {
        console.log(MenArr[i]);
      });
    }
  } else if (category === "HOO-WOMEN") {
    for (let i = 0; i < WomenArr.length; i++) {
      tableRows[i].addEventListener("click", function () {
        console.log(WomenArr[i]);
      });
    }
  } else if (category === "HOO-CHILDREN") {
    for (let i = 0; i < ChildrenArr.length; i++) {
      tableRows[i].addEventListener("click", function () {
        console.log(ChildrenArr[i]);
      });
    }
  }
}

// Creates all the cells for a particular category
function createCells(category) {
  // Fetching the tbody element
  var tbodyRef = document.getElementById("category-products"); // Corrected ID

  // Iterating through the products and creating rows
  for (let i = 0; i < products.length; i++) {
    // Iterating over array
    products[i].categories.forEach(function (element) {
      if (element === category && products[i].discontinued === false) {
        // creates a table row
        var newRow = tbodyRef.insertRow();
        newRow.className = "tbl-row";

        // Insert a cell at the end of the row
        var newCell = newRow.insertCell();
        // Append a text node to the cell
        var newText = document.createTextNode(products[i].title);
        newCell.appendChild(newText);

        // Insert a cell at the end of the row
        newCell = newRow.insertCell();
        newCell.id = i;
        // Append a text node to the cell
        newText = document.createTextNode(products[i].description);
        newCell.appendChild(newText);

        // Insert a cell at the end of the row
        newCell = newRow.insertCell();
        // Append a text node to the cell
        newText = document.createTextNode(
          (products[i].price / 100).toLocaleString("en-CA", { currency: "CAD", style: "currency" })
        ); // Converting to Canadian Currency
        newCell.appendChild(newText);
      }
    });
  }
}

// Display men hoodies by default
document.getElementById("category-products").innerHTML = ""; // Corrected ID
document.getElementById("selected-category").textContent = "Men";
createCells("HOO-MEN");

// Function that shows a product list based on category and updates the heading
function showProductList(category) {
  // Clearing all the elements so that they don't stay
  document.getElementById("category-products").innerHTML = ""; // Corrected ID

  // Changing the human-readable names to IDs
  for (let k = 0; k < categories.length; k++) {
    if (categories[k].name === category) {
      category = categories[k].id;
    }
  }

  // Creating cells for categories
  createCells(category);
  descriptionPrinter(category);
}

// Change the heading and show the product list
let menuArr = document.querySelector("#menu").querySelectorAll("button");
for (let i = 0; i < menuArr.length; i++) {
  menuArr[i].addEventListener("click", function () {
    document.getElementById("selected-category").innerHTML = menuArr[i].textContent;
    showProductList(menuArr[i].textContent);
  });
}

// As the default category is men, we call the function by passing 'HOO-MEN' as the category
descriptionPrinter("HOO-MEN");
