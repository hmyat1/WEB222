function observationSummary(data) {
  for (let i in data.results) {
    console.log(
      '#' +
        data.results[i].id +
        ' - ' +
        data.results[i].species_guess +
        ' ' +
        `(${data.results[i].observed_on_details.date})`
    );
  }
}
